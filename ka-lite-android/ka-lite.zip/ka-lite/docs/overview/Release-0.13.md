### Target Release Date ###

End of March, 2014

### Goals ###

Increase our user-base and community support, and gather as much user data as possible.

### High-level Plan ###

Automate the registration process and simplify the installation process.
 
### Release criteria and status ###
