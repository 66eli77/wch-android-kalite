########################
# Django dependencies
########################

INSTALLED_APPS = (
    "securesync",
)

#######################
# Set module settings
#######################
