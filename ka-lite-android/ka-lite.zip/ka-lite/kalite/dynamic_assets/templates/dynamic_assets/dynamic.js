{% load my_filters %}

var ds = {{ ds|jsonify }};
