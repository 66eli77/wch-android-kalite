USE_I18N = False
USE_L10N = False
DEBUG = False
USE_I18N = False
USE_L10N = False
DEBUG = False
