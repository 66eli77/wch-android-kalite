"""
These use a web-browser, along selenium, to simulate user actions.
"""
